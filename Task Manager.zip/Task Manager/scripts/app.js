var important = false;
var icon;

function togglePriority() {
    console.log("Clicked");

    if (important == true) {

        $("#iPriority").removeClass("far").addClass("fas");
        important = false;
    } else {
        $("#iPriority").removeClass("fas").addClass("far");
        important = true;
    }

    $("#formButton").click(function () {
        $(".section-form").hide();

    });

}

function init() {
    console.log("Task manager");
    icon = $("#iPriority");
    //hook events
    icon.click(togglePriority);
    //load data

}

window.onload = init;